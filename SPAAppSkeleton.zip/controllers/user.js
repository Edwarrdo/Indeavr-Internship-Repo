const user = (function(){
    const getLogin = function(ctx){
        ctx.partial('views/user/login.hbs');
    };

    const postLogin = function(ctx){
        var username = ctx.params.username;
        var password = ctx.params.password;
        
        userModel.login(username, password).done(function(data){
            storage.saveUser(data);
            notification.info("Successfully logged in!")
            ctx.redirect('#/');
        }).fail(function(){
            notification.error("Wrong username or password!")
        });
    };

    const logout = function(ctx){
        userModel.logout().done(function(){
            storage.deleteUser();
            notification.info("Successfully logged out!")
            ctx.redirect('#/');
        }).fail(function(){
            notification.error("Something went wrong!")
        });
    }

    const getRegister = function(ctx) {
        ctx.partial('views/user/register.hbs');
    };

    const postRegister = function(ctx) {
        userModel.register(ctx.params).done(function(data){
            storage.saveUser(data);
            notification.info("Successfully registered user!");
            ctx.redirect('#/');
        }).fail(function(){
            notification.error("Couldn't register user!");
        });
    }

    const initializeLogin = function(){
        if(!userModel.isAuthorized()){
            $(".notLoggedIn").removeClass("d-none");
            $(".loggedIn").addClass("d-none");
        } else{
            $(".notLoggedIn").addClass("d-none");
            $(".loggedIn").removeClass("d-none");
            $("#userNameSpan").text(userModel.getUserName());
        }
    };

    return {
        getLogin,
        postLogin,
        logout,
        getRegister,
        postRegister,
        initializeLogin
    };
}());