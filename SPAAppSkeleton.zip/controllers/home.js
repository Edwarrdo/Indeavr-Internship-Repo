 const home = (function(){
    const index = function(ctx) {
        requester.get(`appdata/${storage.appKey}/flights`).done(function(data){
            ctx.flights = data;
            console.log(data);
            ctx.partial("views/home/home.hbs");
        })
    };

    return {
        index
    };
}());