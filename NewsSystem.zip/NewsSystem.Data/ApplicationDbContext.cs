﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using NewsSystem.Models;

namespace NewsSystem.Data
{
    public class ApplicationDbContext : IdentityDbContext<User>
    {
        public DbSet<Category> Categories { get; set; }

        public DbSet<Article> Articles { get; set; }

        public DbSet<Like> Likes { get; set; }
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Article>()
                .HasOne(article => article.Author)
                .WithMany(author => author.Articles)
                .HasForeignKey(article => article.AuthorId);

            builder.Entity<Article>()
                .HasOne(article => article.Category)
                .WithMany(cat => cat.Articles)
                .HasForeignKey(article => article.CategoryId);

            builder.Entity<Like>()
                .HasOne(like => like.Article)
                .WithMany(art => art.Likes)
                .HasForeignKey(like => like.ArticleId);

            builder.Entity<Like>()
                .HasOne(like => like.User)
                .WithMany(user => user.Likes)
                .HasForeignKey(like => like.UserId);

            base.OnModelCreating(builder);
        }
    }
}
