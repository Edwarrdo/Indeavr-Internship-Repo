﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NewsSystem.Web.Areas.Administration.Models.BindingModels
{
    public class CategoryCreationBindingModel
    {
        [Required]
        [MinLength(2, ErrorMessage = "Name must be at least 2 symbols long!")]
        [MaxLength(30, ErrorMessage = "Name must be at max 30 symbols long!")]
        public string Name { get; set; }
    }
}
