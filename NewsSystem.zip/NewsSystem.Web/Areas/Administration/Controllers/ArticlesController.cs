﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NewsSystem.Data;
using NewsSystem.Models;
using NewsSystem.Web.Areas.Administration.Models.BindingModels;
using NewsSystem.Web.Models;
using NewsSystem.Web.Models.CustomClass;
using ReflectionIT.Mvc.Paging;

namespace NewsSystem.Web.Areas.Administration.Controllers
{
    [Authorize]
    [Area("Administration")]
    public class ArticlesController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IArticleSorter sorter;

        public ArticlesController(ApplicationDbContext context, IArticleSorter sorter)
        {
            _context = context;
            this.sorter = sorter;
        }

        // GET: Administration/Articles
        public async Task<IActionResult> Index(string sorting = "none", int page = 1)
        {
            switch(sorting)
            {
                case "date":
                    switch(sorter.DateStrategy)
                    {
                        case "desc":
                            var items = _context.Articles.Include(a => a.Category).Include(a => a.Author).AsNoTracking().OrderByDescending(a => a.DateCreated);
                            var model = await PagingList.CreateAsync<Article>(items, 5, page);
                            return View(model);
                        default:
                            items = _context.Articles.Include(a => a.Category).Include(a => a.Author).AsNoTracking().OrderBy(a => a.DateCreated);
                            model = await PagingList.CreateAsync<Article>(items, 5, page);
                            return View(model);
                    }
                case "title":
                    switch (sorter.TitleStrategy)
                    {
                        case "desc":
                            var items = _context.Articles.Include(a => a.Category).Include(a => a.Author).AsNoTracking().OrderByDescending(a => a.Title);
                            var model = await PagingList.CreateAsync<Article>(items, 5, page);
                            return View(model);
                        default:
                            items = _context.Articles.Include(a => a.Category).Include(a => a.Author).AsNoTracking().OrderBy(a => a.Title);
                            model = await PagingList.CreateAsync<Article>(items, 5, page);
                            return View(model);
                    }
            }
            
            var itemss = _context.Articles.Include(a => a.Category).Include(a => a.Author).AsNoTracking().OrderByDescending(a => a.Id);
            var modell = await PagingList.CreateAsync<Article>(itemss, 5, page);
            return View(modell);

        }
        
        public async Task<IActionResult> Like(int id)
        {
            var currUser = _context.Users.FirstOrDefault(u => u.UserName == this.User.Identity.Name);
            var like = new Like()
            {
                ArticleId = id,
                UserId = currUser.Id
            };
            currUser.Likes.Add(like);
            await _context.SaveChangesAsync();
            this.TempData["goodMessage"] = "You liked this article!";

            return RedirectToAction("Details", "Articles", new { area = "Administration", id=id });

        }

        public async Task<IActionResult> Unlike(int id)
        {
            var currUser = _context.Users.FirstOrDefault(u => u.UserName == this.User.Identity.Name);

            var like = _context.Likes.FirstOrDefault(l => l.ArticleId == id);
            _context.Likes.Remove(like);
            await _context.SaveChangesAsync();
            this.TempData["goodMessage"] = "You unliked this article!";


            return RedirectToAction("Details", "Articles", new { area = "Administration", id = id });

        }

        // GET: Administration/Articles/Details/5
        [AllowAnonymous]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var article = await _context.Articles
                .Include(a => a.Author)
                .Include(a => a.Category)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (article == null)
            {
                return NotFound();
            }
            var likes = _context.Likes
                .Select(l => l.ArticleId).ToList();
            this.ViewData["Liked"] = likes.Contains(article.Id) == true ? "yes" : "no";

            return View(article);
        }

        // GET: Administration/Articles/Create
        [HttpGet]
        public IActionResult Create()
        {
            var categories = _context.Categories.Include(c => c.Articles).Select(c => c.Name).ToList();
            this.ViewBag.Categories = categories;
            return View();
        }

        // POST: Administration/Articles/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ArticleCreationBindingModel model)
        {
            if (!ModelState.IsValid)
            {
                this.TempData["badMessage"] = "Couldn't create the article!";
                return View();
            }
            var category = _context.Categories.FirstOrDefault(c => c.Name == model.Category);
            var author = _context.Users.FirstOrDefault(u => u.UserName == this.User.Identity.Name);
            var article = new Article()
            {
                Title = model.Title,
                Content = model.Content,
                Author = author,
                AuthorId = author.Id,
                DateCreated = DateTime.Now,
                CategoryId = category.Id
            };

            _context.Articles.Add(article);
            await _context.SaveChangesAsync();
            this.TempData["goodMessage"] = "Article created!";
            return RedirectToAction("Index", "Articles", new { area = "Administration" });
        }

        // GET: Administration/Articles/Edit/5
        [Authorize]

        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var article = _context.Articles.Include(a => a.Category).FirstOrDefault(a => a.Id == id);
            if (article == null)
            {
                this.TempData["badMessage"] = "No such article found!";
                return NotFound();
            }
            var categories = _context.Categories.Select(c => c.Name).ToList();
            this.ViewBag.Categories = categories;
            return View(article);
        }

        // POST: Administration/Articles/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,Content,DateCreated,Likes")] Article article, [Bind("Category")] string Category, [Bind("AuthorId")] string AuthorId)
        {
            if (id != article.Id)
            {
                this.TempData["badMessage"] = "No such article found!";
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    article.CategoryId = _context.Categories.FirstOrDefault(c => c.Name == Category).Id;
                    article.AuthorId = _context.Users.FirstOrDefault(u => u.Id == AuthorId).Id;
                    _context.Update(article);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ArticleExists(article.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                this.TempData["goodMessage"] = "Article changed!";
                return RedirectToAction(nameof(Index));
            }
            this.TempData["badMessage"] = "No such article found!";
            return View(article);
        }

        // GET: Administration/Articles/Delete/5
        [Authorize]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                this.TempData["badMessage"] = "No such article found!";
                return NotFound();
            }

            var article = await _context.Articles
                .Include(a => a.Category)
                .FirstOrDefaultAsync(m => m.Id == id);
            this.ViewBag.AuthorName = _context.Users.FirstOrDefault(u => u.Id == article.AuthorId).UserName;
            if (article == null)
            {
                return NotFound();
            }
            return View(article);
        }

        // POST: Administration/Articles/Delete/5
        [Authorize]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var article = await _context.Articles.FindAsync(id);
            _context.Articles.Remove(article);
            await _context.SaveChangesAsync();
            this.TempData["goodMessage"] = "Article deleted!";
            return RedirectToAction(nameof(Index));
        }

        private bool ArticleExists(int id)
        {
            return _context.Articles.Any(e => e.Id == id);
        }

        public IActionResult SortByTitle()
        {
            if(sorter.TitleStrategy == "asc")
            {
                sorter.TitleStrategy = "desc";
            }
            else
            {
                sorter.TitleStrategy = "asc";
            }
            return RedirectToAction("Index", "Articles", new { area = "Administration", sorting = "title" });

        }

        public IActionResult SortByDate()
        {
            if (sorter.DateStrategy == "asc")
            {
                sorter.DateStrategy = "desc";
            }
            else
            {
                sorter.DateStrategy = "asc";
            }
            return RedirectToAction("Index", "Articles", new { area = "Administration", sorting = "date" });

        }
    }
}
