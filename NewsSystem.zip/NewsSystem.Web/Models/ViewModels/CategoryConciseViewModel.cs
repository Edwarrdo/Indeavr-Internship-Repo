﻿using System.Collections.Generic;

namespace NewsSystem.Web.Models.ViewModels
{
    public class CategoryConciseViewModel
    {
        public string Name { get; set; }
        public List<ArticleConciseViewModel> LatestArticles { get; set; }
    }
}