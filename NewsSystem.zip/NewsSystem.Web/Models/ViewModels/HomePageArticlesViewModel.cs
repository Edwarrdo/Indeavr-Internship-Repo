﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewsSystem.Web.Models.ViewModels
{
    public class HomePageArticlesViewModel
    {
        public List<ArticleConciseViewModel> TopArticles { get; set; }
        public List<CategoryConciseViewModel> Categories { get; set; }
    }
}
