﻿namespace NewsSystem.Web.Models.ViewModels
{
    public class ArticleConciseViewModel
    {
        public int Id { get; set; }
        public string Title { get; set; }

        public string Author { get; set; }
    }
}