﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NewsSystem.Data;
using NewsSystem.Web.Models;
using NewsSystem.Web.Models.ViewModels;

namespace NewsSystem.Web.Controllers
{
    public class HomeController : Controller
    {
        private ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            this._context = context;
        }
        public IActionResult Index()
        {
            var topArticles = _context
                                .Articles
                                .OrderByDescending(a => a.Likes.Count)
                                .Take(3)
                                .Select(a => new ArticleConciseViewModel
                                {
                                    Id = a.Id,
                                    Title = a.Title,
                                    Author = _context.Users.FirstOrDefault(u => u.Id == a.AuthorId).UserName
                                }
                ).ToList();
            var categories = _context.Categories
                .Select(c => new CategoryConciseViewModel
                {
                    Name = c.Name,
                    LatestArticles = c.Articles
                                .OrderByDescending(a => a.DateCreated).Take(3)
                                .Select(a => new ArticleConciseViewModel
                                 {
                                    Id = a.Id,
                                     Title = a.Title,
                                     Author = _context.Users.FirstOrDefault(u => u.Id == a.AuthorId).UserName
                                 }).ToList()
                }).ToList();
            var model = new HomePageArticlesViewModel()
            {
                Categories = categories,
                TopArticles = topArticles
            };
            var currentUserLikes = _context.Users
                .FirstOrDefault(u => u.UserName == this.User.Identity.Name);
            return View(model);
        }

        [HttpGet]
        [Route("api/Get")]
        public IActionResult GetData()
        {
            return Json(this._context.Users);
        }
        public IActionResult About()
        {
            return this.View();
        }

        public IActionResult Contact()
        {
            return this.View();
        }
        
    }
}
