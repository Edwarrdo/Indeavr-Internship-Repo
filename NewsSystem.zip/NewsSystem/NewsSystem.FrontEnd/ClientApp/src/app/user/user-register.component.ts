import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../Shared/Services/UserService';
import { Router } from '@angular/router';

@Component({
  selector: 'user-register',
  templateUrl: './user-register.component.html',
  styles: [
    `em { color: #E05C65}`
  ]
})
export class UserRegisterComponent {

  constructor(private userService: UserService, private router: Router) { }
  
  registerForm = new FormGroup({
    UserName: new FormControl('', Validators.required),
    Password: new FormControl('', Validators.required)
  });

  onSubmit() {
    let username = this.registerForm.controls["UserName"].value;
    let password = this.registerForm.controls["Password"].value;
    this.userService.registerUser(username, password).subscribe(user => this.setUser(user));
  }

  setUser(user) {
    this.userService.CurrentUser = { id: user.id, username: user.userName, passwordHash: user.passwordHash };
    this.router.navigate(['/']);
  }

  validatePassword() {
    let password = this.registerForm.controls["Password"];
    return !password.valid || +password.value.length > 3;
  }

  validateName() {
    let name = this.registerForm.controls["UserName"];
    return !name.valid || +name.value.length > 2;
  }

  validateForm() {
    return this.validatePassword && this.validateName() && this.registerForm.valid;
  }
}

