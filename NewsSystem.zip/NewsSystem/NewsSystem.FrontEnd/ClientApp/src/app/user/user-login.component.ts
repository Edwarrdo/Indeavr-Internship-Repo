import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../Shared/Services/UserService';
import { Router } from '@angular/router';

@Component({
  selector: 'user-login',
  templateUrl: './user-login.component.html',
  styles: [
    `em { color: #E05C65}`
  ]
})
export class UserLoginComponent {

  constructor(private userService: UserService,
              private router: Router) { }

  loginForm = new FormGroup({
    UserName: new FormControl('', Validators.required),
    Password: new FormControl('', Validators.required)
  });

  onSubmit() {
    let username = this.loginForm.controls["UserName"].value;
    let password = this.loginForm.controls["Password"].value;
    this.userService.loginUser(username, password).subscribe(user => this.setUser(user),
      error => this.handleError(error));
  }

  setUser(user) {
    this.userService.CurrentUser = { id: user.id, username: user.userName, passwordHash: user.passwordHash };
    this.router.navigate(['/']);
  }

  handleError(error) {
    this.router.navigate(['register']);
  }

  
}

