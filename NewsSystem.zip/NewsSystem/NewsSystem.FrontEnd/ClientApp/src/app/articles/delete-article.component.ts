import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ArticleService } from '../Shared/Services/ArticleService';

@Component({
  selector: 'delete-article',
  templateUrl: './delete-article.component.html'
})
export class DeleteArticleComponent implements OnInit {

  constructor(private articleService: ArticleService, private router: Router, private route: ActivatedRoute) { }
  article;

  ngOnInit() {
    this.articleService.getArticle(+this.route.snapshot.params["id"]).subscribe(art => this.setArticle(art));

  }
  setArticle(art) {
    this.article = art;
  }
  delete(id: number) {
    this.articleService.delete(id).subscribe(art => this.router.navigate(['articles/all']));
  }
}




