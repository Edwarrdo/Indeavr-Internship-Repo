import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CategoryService } from '../Shared/Services/CategoryService';
import { ArticleService } from '../Shared/Services/ArticleService';
import { UserService } from '../Shared/Services/UserService';
import { Router } from '@angular/router';

@Component({
  selector: 'create-article',
  templateUrl: './create-article.component.html',
  styles: [
    `em { color: #E05C65}`
  ]
})
export class CreateArticleComponent implements OnInit {

  constructor(private categoryService: CategoryService,
    private articleService: ArticleService,
    private userService: UserService,
    private router: Router) { }
  categories;

  createForm = new FormGroup({
    Title: new FormControl('', Validators.required),
    Content: new FormControl('', Validators.required),
    Category: new FormControl('', Validators.required)
  })

  ngOnInit() {
    this.categoryService.getAllCategories().subscribe(categoryList => this.categories = categoryList);
  }

  createArticle() {
    let title = this.createForm.controls["Title"].value;
    let content = this.createForm.controls["Content"].value;
    let category = this.createForm.controls["Category"].value;
    this.articleService.createArticle(title, content, category, this.userService.CurrentUser.id).subscribe(art => this.router.navigate(['articles/all']));
  }
}




