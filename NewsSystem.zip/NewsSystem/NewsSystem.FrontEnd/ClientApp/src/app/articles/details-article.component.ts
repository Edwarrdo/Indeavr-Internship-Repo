import { Component, OnInit } from '@angular/core';
import { ArticleService } from '../Shared/Services/ArticleService';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'details-article',
  templateUrl: './details-article.component.html'
})
export class DetailsArticleComponent implements OnInit {

  constructor(private articleService: ArticleService,
    private route: ActivatedRoute) { }
    article;
  

  ngOnInit() {
    this.articleService.getArticle(+this.route.snapshot.params["id"]).subscribe(art => this.setArticle(art));
  }

  setArticle(art) {
    this.article = art;
  }
  
}




