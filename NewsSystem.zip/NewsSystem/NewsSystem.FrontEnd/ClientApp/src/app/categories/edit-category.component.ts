import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CategoryService } from '../Shared/Services/CategoryService';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'edit-category',
  templateUrl: './edit-category.component.html',
  styles: [
    `em { color: #E05C65}`
  ]
})
export class EditCategoryComponent implements OnInit {

  constructor(private categoryService: CategoryService, private router: Router, private route: ActivatedRoute) { }
  category;
  categoryName = new FormControl('', Validators.required);

  ngOnInit() {
    this.categoryService.getCategory(+this.route.snapshot.params["id"]).subscribe(cat => this.setCategory(cat));

  }
  setCategory(cat) {
    this.category = cat;
    this.categoryName.setValue(cat.name);
  }
  setUpdatedCategory(cat) {
    this.category = cat;
    this.categoryName.setValue(cat.name);
    this.router.navigate(['categories/all']);
  }
  edit(id: number) {
    this.categoryService.edit(id, this.categoryName.value).subscribe(cat => this.setUpdatedCategory(cat));
  }
}




