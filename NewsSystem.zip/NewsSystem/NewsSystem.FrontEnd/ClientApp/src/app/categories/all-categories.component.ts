import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { CategoryService } from '../Shared/Services/CategoryService';

@Component({
  selector: 'all-categories',
  templateUrl: './all-categories.component.html'
})
export class AllCategoriesComponent implements OnInit {

  constructor(private categoryService: CategoryService) { }
  p: number = 1;
  sortingStrategy: string;
  categories;

  ngOnInit() {
    this.categoryService.getAllCategories().subscribe(categoryList => this.categories = categoryList);
    this.sortingStrategy = "none";
  }

  sort() {
    if (this.sortingStrategy === "none") {
      this.sortingStrategy = "asc";
      this.categories.sort(this.ascendingSort);
    } else if (this.sortingStrategy === "asc") {
      this.sortingStrategy = "desc";
      this.categories.sort(this.descendingSort);
    } else {
      this.sortingStrategy = "asc";
      this.categories.sort(this.ascendingSort);
    }
  }

  ascendingSort(a, b) {
    if (a.name > b.name) {
      return 1;
    } else if (a.name === b.name) {
      return 0;
    } else {
      return -1;
    }
  }
  descendingSort(a, b) {
    if (b.name > a.name) {
      return 1;
    } else if (b.name === a.name) {
      return 0;
    } else {
      return -1;
    }
  }
}
  
  


