import { Component, OnInit } from '@angular/core';
import { CategoryService } from '../Shared/Services/CategoryService';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'delete-category',
  templateUrl: './delete-category.component.html'
})
export class DeleteCategoryComponent implements OnInit {

  constructor(private categoryService: CategoryService, private router: Router, private route: ActivatedRoute) { }
  category;
  categoryName: string;

  ngOnInit() {
    this.categoryService.getCategory(+this.route.snapshot.params["id"]).subscribe(cat => this.setCategory(cat));
  }
  setCategory(cat) {
    this.category = cat;
    this.categoryName = cat.name ;
  }
  delete(id: number) {
    this.categoryService.delete(id).subscribe(cat => this.router.navigate(['categories/all']));
  }
}




