import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CategoryService } from '../Shared/Services/CategoryService';
import { Router } from '@angular/router';

@Component({
  selector: 'create-category',
  templateUrl: './create-category.component.html',
  styles: [
    `em { color: #E05C65}`
  ]
})
export class CreateCategoryComponent{

  constructor(private categoryService: CategoryService, private router: Router) { }
  
  createForm = new FormGroup({
    Name: new FormControl('', Validators.required),
  });

  createCategory() {
    let name = this.createForm.controls["Name"].value;
    this.categoryService.createCategory(name).subscribe(cat => this.router.navigate(['categories/all']));
  }
  
}




