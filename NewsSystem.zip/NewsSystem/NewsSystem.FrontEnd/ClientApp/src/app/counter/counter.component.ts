import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-counter-component',
  templateUrl: './counter.component.html'
})
export class CounterComponent {

  constructor(private http : HttpClient) { }

  public currentCount = 0;
  public hasData: boolean = false;
  public data: any;
  public apiUrl = `https://localhost:44344/api/Get`;
  public incrementCounter() {
    this.currentCount++;
    this.http.get(this.apiUrl).subscribe(data2 => this.data = data2);
  }

  
  
}
