import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { HomeComponent } from './home/home.component';
import { CounterComponent } from './counter/counter.component';
import { FetchDataComponent } from './fetch-data/fetch-data.component';
import { UserRegisterComponent } from './user/user-register.component';
import { UserService } from './Shared/Services/UserService';
import { UserLoginComponent } from './user/user-login.component';
import { AllCategoriesComponent } from './categories/all-categories.component';
import { CategoryService } from './Shared/Services/CategoryService';
import { NgxPaginationModule } from 'ngx-pagination';
import { CreateCategoryComponent } from './categories/create-category.component';
import { EditCategoryComponent } from './categories/edit-category.component';
import { DeleteCategoryComponent } from './categories/delete-category.component';
import { ArticleService } from './Shared/Services/ArticleService';
import { CreateArticleComponent } from './articles/create-article.component';
import { AllArticlesComponent } from './articles/all-articles.component';
import { EditArticleComponent } from './articles/edit-article.component';
import { DeleteArticleComponent } from './articles/delete-article.component';
import { AuthenticateGuard } from './Shared/Guards/authenticate-guard';
import { DetailsArticleComponent } from './articles/details-article.component';

@NgModule({
  declarations: [
    AppComponent,
    NavMenuComponent,
    HomeComponent,
    CounterComponent,
    FetchDataComponent,
    UserRegisterComponent,
    UserLoginComponent,
    AllCategoriesComponent,
    CreateCategoryComponent,
    EditCategoryComponent,
    DeleteCategoryComponent,
    CreateArticleComponent,
    AllArticlesComponent,
    EditArticleComponent,
    DeleteArticleComponent,
    DetailsArticleComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    RouterModule.forRoot([
      { path: '', component: HomeComponent, pathMatch: 'full' },
      { path: 'register', component: UserRegisterComponent },
      { path: 'login', component: UserLoginComponent },
      { path: 'counter', component: CounterComponent },
      { path: 'fetch-data', component: FetchDataComponent },
      { path: 'categories/all', component: AllCategoriesComponent, canActivate: [AuthenticateGuard] },
      { path: 'categories/create', component: CreateCategoryComponent, canActivate: [AuthenticateGuard]  },
      { path: 'categories/edit/:id', component: EditCategoryComponent, canActivate: [AuthenticateGuard]  },
      { path: 'categories/delete/:id', component: DeleteCategoryComponent, canActivate: [AuthenticateGuard]  },
      { path: 'articles/create', component: CreateArticleComponent, canActivate: [AuthenticateGuard]  },
      { path: 'articles/all', component: AllArticlesComponent, canActivate: [AuthenticateGuard]  },
      { path: 'articles/edit/:id', component: EditArticleComponent, canActivate: [AuthenticateGuard]  },
      { path: 'articles/delete/:id', component: DeleteArticleComponent, canActivate: [AuthenticateGuard] },
      { path: 'articles/details/:id', component: DetailsArticleComponent },
      { path: '**', component: HomeComponent }
    ])
  ],
  providers: [UserService, CategoryService, ArticleService, AuthenticateGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
