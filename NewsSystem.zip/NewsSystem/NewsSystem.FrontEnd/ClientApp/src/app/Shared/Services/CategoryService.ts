import { Injectable, OnChanges, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable()
export class CategoryService
{
  categoryUrl: string = 'https://localhost:44344/api/Categories/';

  constructor(private http: HttpClient) { }
  
  getAllCategories() {
    return this.http.get(this.categoryUrl + 'All');
  }

  createCategory(name: string) {
    let options = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post(this.categoryUrl + 'Create', { Name: name }, options);
  }

  getCategory(id: number) {
    return this.http.get(this.categoryUrl + id);
  }

  edit(id: number, newName: string) {
    let options = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.put(this.categoryUrl + id, { Name: newName, Id: id }, options);
  }

  delete(id: number) {
    return this.http.delete(this.categoryUrl + id);
  }
}
