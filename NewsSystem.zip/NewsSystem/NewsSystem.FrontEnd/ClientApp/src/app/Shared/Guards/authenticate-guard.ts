import { Injectable, OnChanges, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UserService } from '../Services/UserService';
import { CanActivate, Router } from '@angular/router';

@Injectable()
export class AuthenticateGuard implements CanActivate {

  constructor(private userService: UserService, private router: Router) { }

  canActivate() {
    if (this.userService.CurrentUser) {
      return true;
    }
    this.router.navigate(['login']);
  }
}
