﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NewsSystem.Data;
using NewsSystem.Models;

namespace NewsSystem.Web.Controllers.UsersController
{
    [ApiController]
    public class UsersController : ControllerBase
    {
        private UserManager<User> _userManager;
        private SignInManager<User> _signInManager;
        private ApplicationDbContext _context;

        public UsersController(UserManager<User> userManager,
            SignInManager<User> signInManager,
            ApplicationDbContext context)
        {
            this._userManager = userManager;
            this._signInManager = signInManager;
            this._context = context;
        }

        // POST: api/Users
        [Route("api/Users/Register")]
        [HttpPost]
        public async Task<IActionResult> Register([FromBody]UserToRegister user)
        {
            if (ModelState.IsValid)
            {
                var newUser = new User { UserName = user.username };
                var result = await _userManager.CreateAsync(newUser, user.password);
                if (result.Succeeded)
                {
                    return this.Ok(newUser);
                }
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
                return BadRequest("Bad information");
            }
            return BadRequest("Bad information");
        }

        [Route("api/Users/Login")]
        [HttpPost]
        public async Task<IActionResult> Login([FromBody]UserToRegister user)
        {
            var result = await _signInManager.PasswordSignInAsync(user.username, user.password, true, lockoutOnFailure: true);
            if (result.Succeeded)
            {
                var currUser = this._context.Users.FirstOrDefault(u => u.UserName == user.username);
                return this.Ok(currUser);
            }
            ModelState.AddModelError(string.Empty, "Invalid login attempt.");
            return BadRequest("Wrong credentials!");
        }

        public class UserToRegister
        {
            public string username { get; set; }

            public string password { get; set; }
        }
    }
}
