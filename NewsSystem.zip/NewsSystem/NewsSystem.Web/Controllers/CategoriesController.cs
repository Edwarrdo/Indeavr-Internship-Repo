﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NewsSystem.Data;
using NewsSystem.Models;

namespace NewsSystem.Web.Controllers
{
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private ApplicationDbContext _context;

        public CategoriesController(ApplicationDbContext context)
        {
            this._context = context;
        }

        [Route("api/Categories/All")]
        [HttpGet]
        public IActionResult All()
        {
            return this.Ok(this._context.Categories.ToList());
        }

        [Route("api/Categories/Create")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Category category)
        {
            this._context.Categories.Add(category);
            await this._context.SaveChangesAsync();
            return this.Ok();
        }

        [Route("api/Categories/{id}")]
        [HttpGet]
        public IActionResult GetCategory(int id)
        {
            return this.Ok(this._context.Categories.FirstOrDefault(c => c.Id == id));
        }

        [Route("api/Categories/{id}")]
        [HttpPut]
        public async Task<IActionResult> UpdateCategory([FromBody] Category Category)
        {
            this._context.Update(Category);
            await this._context.SaveChangesAsync();
            return this.Ok(Category);
        }

        [Route("api/Categories/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            var category = this._context.Categories.FirstOrDefault(c => c.Id == id);
            if(category == null)
            {
                return NotFound();
            }
            this._context.Categories.Remove(category);
            await this._context.SaveChangesAsync();
            return this.Ok();
        }

    }
}
