﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NewsSystem.Data;
using NewsSystem.Models;
using NewsSystem.Web.Models.ViewModels;

namespace NewsSystem.Web.Controllers
{
    [ApiController]
    public class ArticlesController : ControllerBase
    {
        private ApplicationDbContext _context;

        public ArticlesController(ApplicationDbContext context)
        {
            this._context = context;
        }

        [Route("api/Articles/All")]
        [HttpGet]
        public IActionResult All()
        {
            var articles = this._context.Articles.Include(a => a.Author).Include(a => a.Category).ToList();
            var result = articles.Select(a => new
            {
                Title = a.Title,
                DateCreated = a.DateCreated.ToShortDateString(),
                CategoryName = a.Category.Name,
                AuthorName = a.Author.UserName,
                Id = a.Id,
                Content = a.Content
            }).ToList();
            return this.Ok(result);
        }

        [Route("api/Articles/Create")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Article Article)
        {
            Article.DateCreated = DateTime.Now;
            this._context.Articles.Add(Article);
            await this._context.SaveChangesAsync();
            return this.Ok(Article);
        }

        [Route("api/Articles/{id}")]
        [HttpGet]
        public IActionResult GetArticle(int id)
        {
            var article = this._context.Articles.Include(a => a.Author).Include(a => a.Category).FirstOrDefault(c => c.Id == id);
            var result = new
            {
                Title = article.Title,
                Content = article.Content,
                AuthorName = article.Author.UserName,
                DateCreated = article.DateCreated.ToShortDateString(),
                Id = article.Id,
                CategoryName = article.Category.Name
            };
            return this.Ok(result);
        }

        [Route("api/Articles/{id}")]
        [HttpPut]
        public async Task<IActionResult> UpdateArticle([FromBody] Article Article)
        {
            Article.DateCreated = DateTime.Now;

            this._context.Update(Article);
            await this._context.SaveChangesAsync();
            return this.Ok(Article);
        }

        [Route("api/Articles/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteArticle(int id)
        {
            var article = this._context.Articles.FirstOrDefault(c => c.Id == id);
            if (article == null)
            {
                return NotFound();
            }
            this._context.Articles.Remove(article);
            await this._context.SaveChangesAsync();
            return this.Ok();
        }


        [Route("api/Articles/Top")]
        [HttpGet]
        public async Task<IActionResult> TopArticles()
        {
            var topArticles = _context
                                .Articles
                                .OrderByDescending(a => a.Likes.Count)
                                .Take(3)
                                .Select(a => new ArticleConciseViewModel
                                {
                                    Id = a.Id,
                                    Title = a.Title,
                                    Author = _context.Users.FirstOrDefault(u => u.Id == a.AuthorId).UserName
                                }
                ).ToList();
            var categories = _context.Categories.Where(c => c.Articles.Count > 0)
                .Select(c => new CategoryConciseViewModel
                {
                    Name = c.Name,
                    LatestArticles = c.Articles
                                .OrderByDescending(a => a.DateCreated).Take(3)
                                .Select(a => new ArticleConciseViewModel
                                {
                                    Id = a.Id,
                                    Title = a.Title,
                                    Author = _context.Users.FirstOrDefault(u => u.Id == a.AuthorId).UserName
                                }).ToList()
                }).ToList();
            var model = new HomePageArticlesViewModel()
            {
                Categories = categories,
                TopArticles = topArticles
            };
            var currentUserLikes = _context.Users
                .FirstOrDefault(u => u.UserName == this.User.Identity.Name);

            return this.Ok(model);
        }
    }
}
