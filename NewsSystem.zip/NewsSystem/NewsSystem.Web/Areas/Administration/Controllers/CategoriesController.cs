﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using NewsSystem.Data;
using NewsSystem.Models;
using NewsSystem.Web.Areas.Administration.Models.BindingModels;
using NewsSystem.Web.Hubs;
using NewsSystem.Web.Models;
using NewsSystem.Web.Models.CustomClass;
using ReflectionIT.Mvc.Paging;

namespace NewsSystem.Web.Areas.Administration.Controllers
{
    [Area("Administration")]
    [Authorize]
    public class CategoriesController : Controller
    {
        private readonly ApplicationDbContext _context;
        private ISortingStrategy strategy;
        private IHubContext<ChatHub> hubContext;

        public CategoriesController(ApplicationDbContext context, ISortingStrategy strategy, IHubContext<ChatHub> _hubContext)
        {
            _context = context;
            this.strategy = strategy;
            this.hubContext = _hubContext;
        }

        // GET: Administration/Categories
        [HttpGet]
        public async Task<IActionResult> Index(int page = 1)
        {
            PagingList<Category> model = await GetModel(page);

            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> IndexPartial(int page = 1)
        {
            PagingList<Category> model = await GetModel(page);

            return PartialView("_View", model);
        }


        private async Task<PagingList<Category>> GetModel(int page)
        {
            PagingList<Category> model = null;

            switch (strategy.Strategy)
            {
                case "asc":
                    var items = _context.Categories.AsNoTracking().OrderBy(c => c.Name);
                    model = await PagingList.CreateAsync<Category>(items, 5, page);
                    break;

                case "desc":
                    items = _context.Categories.AsNoTracking().OrderByDescending(c => c.Name);
                    model = await PagingList.CreateAsync<Category>(items, 5, page);
                    break;

                default:
                    items = _context.Categories.AsNoTracking().OrderBy(c => c.Id);
                    model = await PagingList.CreateAsync<Category>(items, 5, page);
                    break;
            }

            return model;
        }

        // GET: Administration/Categories/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var category = await _context.Categories
                .FirstOrDefaultAsync(m => m.Id == id);
            if (category == null)
            {
                return NotFound();
            }

            return View(category);
        }

        // GET: Administration/Categories/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Administration/Categories/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CategoryCreationBindingModel model)
        {
            if (ModelState.IsValid)
            {
                if (_context.Categories.FirstOrDefault(c => c.Name == model.Name) == null)
                {
                    var category = new Category()
                    {
                        Name = model.Name
                    };

                    _context.Add(category);
                    await _context.SaveChangesAsync();
                    this.TempData["goodMessage"] = "Category created!";
                    await hubContext.Clients.All.SendAsync("ReloadCategories");

                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    //TODO: Add error message
                    this.TempData["badMessage"] = "Category couldn't be created!";

                    
                    return View();
                }
            }

            return View(model);
        }

        // GET: Administration/Categories/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                this.TempData["badMessage"] = "Please enter id!";
                return NotFound();
            }

            var category = await _context.Categories.FindAsync(id);
            if (category == null)
            {
                this.TempData["badMessage"] = "No category with such id!";
                return NotFound();
            }
            return View(category);
        }

        // POST: Administration/Categories/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name")] Category category)
        {
            if (id != category.Id)
            {
                this.TempData["badMessage"] = "Wrong id!";
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(category);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CategoryExists(category.Id))
                    {
                        this.TempData["badMessage"] = "No category with such id!";
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                this.TempData["goodMessage"] = "Category changed!";
                return RedirectToAction(nameof(Index));
            }
            this.TempData["badMessage"] = "Something went wrong!";
            return View(category);
        }

        // GET: Administration/Categories/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                this.TempData["badMessage"] = "Please enter id!";
                return NotFound();
            }

            var category = await _context.Categories
                .FirstOrDefaultAsync(m => m.Id == id);
            if (category == null)
            {
                this.TempData["badMessage"] = "No category with such id!";
                return NotFound();
            }

            return View(category);
        }

        // POST: Administration/Categories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var category = await _context.Categories.FindAsync(id);
            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();
            this.TempData["goodMessage"] = "Category deleted!";
            return RedirectToAction(nameof(Index));
        }

        private bool CategoryExists(int id)
        {
            return _context.Categories.Any(e => e.Id == id);
        }

        [HttpGet]
        public IActionResult Sort()
        {
            if (strategy.Strategy == "none")
            {
                strategy.Strategy = "asc";
            }
            else if (strategy.Strategy == "asc")
            {
                strategy.Strategy = "desc";
            }
            else
            {
                strategy.Strategy = "asc";
            }
            return RedirectToAction("Index", "Categories", new { area = "Administration" });
        
    }
    }
}

