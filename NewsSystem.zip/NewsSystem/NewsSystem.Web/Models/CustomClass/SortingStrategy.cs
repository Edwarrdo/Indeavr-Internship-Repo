﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewsSystem.Web.Models.CustomClass
{
    public class SortingStrategy : ISortingStrategy
    {
        public string Strategy { get; set; } = "none";
    }
}
