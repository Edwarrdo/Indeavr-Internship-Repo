﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewsSystem.Web.Models.CustomClass
{
    public class ArticleSorter : IArticleSorter
    {
        public string DateStrategy { get; set; } = "none";
        public string TitleStrategy { get; set; } = "none";
    }
}
