﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NewsSystem.Models
{
    public class Article
    {
        public int Id { get; set; }

        [Required]
        public string Title { get; set; }

        public string Content { get; set; }

        public int CategoryId { get; set; }
        public Category Category { get; set; }

        public string AuthorId { get; set; }
        public User Author { get; set; }

        public DateTime DateCreated { get; set; }

        public ICollection<Like> Likes { get; set; } = new List<Like>();
    }
}
