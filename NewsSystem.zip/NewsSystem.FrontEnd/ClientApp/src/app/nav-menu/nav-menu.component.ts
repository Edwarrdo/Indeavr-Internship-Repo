import { Component, OnInit, OnChanges, Output } from '@angular/core';
import { UserService } from '../Shared/Services/UserService';
import { EventEmitter } from 'protractor';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nav-menu',
  templateUrl: './nav-menu.component.html'
})
export class NavMenuComponent {
  isExpanded = false;
  constructor(private userService: UserService, private router: Router) { }

  isAuthenticated: boolean ;

  LogOut() {
    //this.userService.CurrentUser = null;
    this.userService.logOut();
    this.router.navigate(['/']);
  }

  collapse() {
    this.isExpanded = false;
  }

  toggle() {
    this.isExpanded = !this.isExpanded;
  }
}
