export interface IUser {
  username: string,
  passwordHash: string,
  id: string
}
