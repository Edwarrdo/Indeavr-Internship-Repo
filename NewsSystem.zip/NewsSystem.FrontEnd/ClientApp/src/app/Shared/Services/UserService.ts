import { Injectable, OnChanges, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { IUser } from '../Interfaces/UserInterface';

@Injectable()
export class UserService {
  CurrentUser: IUser;
  

  userUrl: string = 'https://localhost:44344/api/Users/';

  constructor(private http: HttpClient) { }

  registerUser(username: string, password: string) {
    let options = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post(this.userUrl + "Register", { username: username, password: password }, options);
  }

  loginUser(username: string, password: string) {
    let options = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post(this.userUrl + "Login", { username: username, password: password }, options);
  }

  logOut() {
    this.CurrentUser = null;
    return null;
  }

}
