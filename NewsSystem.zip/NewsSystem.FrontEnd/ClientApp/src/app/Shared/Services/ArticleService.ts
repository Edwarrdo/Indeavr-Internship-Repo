import { Injectable, OnChanges, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable()
export class ArticleService {
  articleUrl: string = 'https://localhost:44344/api/Articles/';

  constructor(private http: HttpClient) { }

  getAllArticles() {
    return this.http.get(this.articleUrl + 'All');
  }

  createArticle(title: string, content: string, categoryId: number, authorId: string) {
    let options = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    console.log(title);
    console.log(content);
    console.log(categoryId);
    console.log(authorId);
    return this.http.post(this.articleUrl + 'Create', { Title: title, Content: content, CategoryId: categoryId, AuthorId: authorId }, options);
  }

  getArticle(id: number) {
    return this.http.get(this.articleUrl + id);
  }

  edit(id: number, title: string, content: string, category: number, authorId: string) {
    let options = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.put(this.articleUrl + id, { Title: title, Id: id, Content: content, CategoryId: category, AuthorId: authorId }, options);
  }

  delete(id: number) {
    return this.http.delete(this.articleUrl + id);
  }

  getTop() {
    return this.http.get(this.articleUrl + "Top");
  }
}
