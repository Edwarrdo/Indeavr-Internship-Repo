import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormControl, FormGroup } from '@angular/forms';
import { UserService } from '../Shared/Services/UserService';

@Component({
  selector: 'user-register',
  templateUrl: './user-register.component.html'
})
export class UserRegisterComponent {

  constructor(private http: HttpClient, private userService: UserService) { }
  
  registerForm = new FormGroup({
    UserName: new FormControl(''),
    Password: new FormControl('')
  });

  onSubmit() {
    let username = this.registerForm.controls["UserName"].value;
    let password = this.registerForm.controls["Password"].value;
    this.userService.registerUser(username, password).subscribe(user => this.setUser(user));
  }

  setUser(user) {
    this.userService.CurrentUser = { id: user.id, username: user.userName, passwordHash: user.passwordHash };
    console.log("id = " + user.id);
    console.log("userName = " + user.userName);
    console.log("passwordHash = " + user.passwordHash);
  }
}

