import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormControl, FormGroup } from '@angular/forms';
import { UserService } from '../Shared/Services/UserService';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'user-login',
  templateUrl: './user-login.component.html'
})
export class UserLoginComponent {

  constructor(private http: HttpClient, private userService: UserService,
              private router: Router) { }

  loginForm = new FormGroup({
    UserName: new FormControl(''),
    Password: new FormControl('')
  });

  onSubmit() {
    let username = this.loginForm.controls["UserName"].value;
    let password = this.loginForm.controls["Password"].value;
    this.userService.loginUser(username, password).subscribe(user => this.setUser(user));
  }

  setUser(user) {
    this.userService.CurrentUser = { id: user.id, username: user.userName, passwordHash: user.passwordHash };
    this.router.navigate(['/']);
  }
}

