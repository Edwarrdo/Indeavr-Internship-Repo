import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormControl, FormGroup } from '@angular/forms';
import { CategoryService } from '../Shared/Services/CategoryService';
import { ArticleService } from '../Shared/Services/ArticleService';
import { UserService } from '../Shared/Services/UserService';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'edit-article',
  templateUrl: './edit-article.component.html'
})
export class EditArticleComponent implements OnInit {

  constructor(private http: HttpClient,
    private categoryService: CategoryService,
    private articleService: ArticleService,
    private userService: UserService,
    private router: Router,
    private route: ActivatedRoute) { }
    categories;
    article;

  editForm = new FormGroup({
    Title: new FormControl(''),
    Content: new FormControl(''),
    Category: new FormControl('')
  })

  ngOnInit() {
    this.categoryService.getAllCategories().subscribe(categoryList => this.categories = categoryList);
    this.articleService.getArticle(+this.route.snapshot.params["id"]).subscribe(art => this.setArticle(art));
  }

  setArticle(art) {
    console.log(art);
    this.editForm.controls["Title"].setValue(art.title);
    this.editForm.controls["Content"].setValue(art.content);
    this.editForm.controls["Category"].setValue(art.categoryId);
    this.article = art;
  }

  edit(id: number) {
    let title = this.editForm.controls["Title"].value;
    let content = this.editForm.controls["Content"].value;
    let category = +this.editForm.controls["Category"].value;
    this.articleService.edit(id, title, content, category, this.userService.CurrentUser.id).subscribe(art => this.router.navigate(['articles/all']));
  }
}




