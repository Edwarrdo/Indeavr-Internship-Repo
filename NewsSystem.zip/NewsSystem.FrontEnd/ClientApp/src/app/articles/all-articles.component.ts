import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormControl, FormGroup } from '@angular/forms';
import { ArticleService } from '../Shared/Services/ArticleService';

@Component({
  selector: 'all-articles',
  templateUrl: './all-articles.component.html'
})
export class AllArticlesComponent implements OnInit {

  constructor(private http: HttpClient, private articlesService: ArticleService) { }
  p: number = 1;
  titleStrategy: string;
  dateStrategy: string;
  articles;

  ngOnInit() {
    this.articlesService.getAllArticles().subscribe(articlesList => this.articles = articlesList);
    this.titleStrategy = "none";
    this.dateStrategy = "none";
  }

  sortByDate() {
    if (this.dateStrategy === "none") {
      this.dateStrategy = "asc";
      this.articles.sort((a, b) => this.ascendingSort(a.dateCreated, b.dateCreated));
    } else if (this.dateStrategy === "asc") {
      this.dateStrategy = "desc";
      this.articles.sort((a, b) => this.descendingSort(a.dateCreated, b.dateCreated));
    } else {
      this.dateStrategy = "asc";
      this.articles.sort((a, b) => this.ascendingSort(a.dateCreated, b.dateCreated));
    }
  }

  sortByTitle() {
    if (this.dateStrategy === "none") {
      this.dateStrategy = "asc";
      this.articles.sort((a, b) => this.ascendingSort(a.title, b.title));
    } else if (this.dateStrategy === "asc") {
      this.dateStrategy = "desc";
      this.articles.sort((a, b) => this.descendingSort(a.title, b.title));
    } else {
      this.dateStrategy = "asc";
      this.articles.sort((a, b) => this.ascendingSort(a.title, b.title));
    }
  }
  ascendingSort(a, b): any {
    if (a > b) {
      return 1;
    } else if (a === b) {
      return 0;
    } else {
      return -1;
    }
  }
  descendingSort(a, b): any {
    if (b > a) {
      return 1;
    } else if (b === a) {
      return 0;
    } else {
      return -1;
    }
  }

}




