import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormControl, FormGroup } from '@angular/forms';
import { CategoryService } from '../Shared/Services/CategoryService';
import { ArticleService } from '../Shared/Services/ArticleService';
import { UserService } from '../Shared/Services/UserService';
import { Router } from '@angular/router';

@Component({
  selector: 'create-article',
  templateUrl: './create-article.component.html'
})
export class CreateArticleComponent implements OnInit {

  constructor(private http: HttpClient,
    private categoryService: CategoryService,
    private articleService: ArticleService,
    private userService: UserService,
    private router: Router) { }
  categories;

  createForm = new FormGroup({
    Title: new FormControl(''),
    Content: new FormControl(''),
    Category: new FormControl('')
  })

  ngOnInit() {
    this.categoryService.getAllCategories().subscribe(categoryList => this.categories = categoryList);
  }

  createArticle() {
    let title = this.createForm.controls["Title"].value;
    let content = this.createForm.controls["Content"].value;
    let category = this.createForm.controls["Category"].value;
    this.articleService.createArticle(title, content, category, this.userService.CurrentUser.id).subscribe(art => this.router.navigate(['articles/all']));
  }
}




