import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { HomeComponent } from './home/home.component';
import { CounterComponent } from './counter/counter.component';
import { FetchDataComponent } from './fetch-data/fetch-data.component';
import { UserRegisterComponent } from './user/user-register.component';
import { UserService } from './Shared/Services/UserService';
import { UserLoginComponent } from './user/user-login.component';
import { AllCategoriesComponent } from './categories/all-categories.component';
import { CategoryService } from './Shared/Services/CategoryService';
import { NgxPaginationModule } from 'ngx-pagination';
import { CreateCategoryComponent } from './categories/create-category.component';
import { EditCategoryComponent } from './categories/edit-category.component';
import { DeleteCategoryComponent } from './categories/delete-category.component';
import { ArticleService } from './Shared/Services/ArticleService';
import { CreateArticleComponent } from './articles/create-article.component';
import { AllArticlesComponent } from './articles/all-articles.component';
import { EditArticleComponent } from './articles/edit-article.component';
import { DeleteArticleComponent } from './articles/delete-article.component';

@NgModule({
  declarations: [
    AppComponent,
    NavMenuComponent,
    HomeComponent,
    CounterComponent,
    FetchDataComponent,
    UserRegisterComponent,
    UserLoginComponent,
    AllCategoriesComponent,
    CreateCategoryComponent,
    EditCategoryComponent,
    DeleteCategoryComponent,
    CreateArticleComponent,
    AllArticlesComponent,
    EditArticleComponent,
    DeleteArticleComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    RouterModule.forRoot([
      { path: '', component: HomeComponent, pathMatch: 'full' },
      { path: 'register', component: UserRegisterComponent },
      { path: 'login', component: UserLoginComponent },
      { path: 'counter', component: CounterComponent },
      { path: 'fetch-data', component: FetchDataComponent },
      { path: 'categories/all', component: AllCategoriesComponent },
      { path: 'categories/create', component: CreateCategoryComponent },
      { path: 'categories/edit/:id', component: EditCategoryComponent },
      { path: 'categories/delete/:id', component: DeleteCategoryComponent },
      { path: 'articles/create', component: CreateArticleComponent },
      { path: 'articles/all', component: AllArticlesComponent },
      { path: 'articles/edit/:id', component: EditArticleComponent },
      { path: 'articles/delete/:id', component: DeleteArticleComponent },
      { path: '**', component: HomeComponent }
    ])
  ],
  providers: [UserService, CategoryService, ArticleService],
  bootstrap: [AppComponent]
})
export class AppModule { }
