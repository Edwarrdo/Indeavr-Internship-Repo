import { Component } from '@angular/core';
import { ArticleService } from '../Shared/Services/ArticleService';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
})
export class HomeComponent {
  topArticles;
  categories;
  constructor(private http: HttpClient, private articleService: ArticleService, private router: Router) { }
  ngOnInit() {
    this.articleService.getTop().subscribe(res => this.handleRes(res));

  }
  handleRes(res) {
    this.topArticles = res.topArticles;
    this.categories = res.categories.filter(c => c.latestArticles.count !== 0);
  }

}
