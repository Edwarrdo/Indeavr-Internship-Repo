import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormControl, FormGroup } from '@angular/forms';
import { CategoryService } from '../Shared/Services/CategoryService';
import { Router } from '@angular/router';

@Component({
  selector: 'create-category',
  templateUrl: './create-category.component.html'
})
export class CreateCategoryComponent{

  constructor(private http: HttpClient, private categoryService: CategoryService, private router: Router) { }
  
  createForm = new FormGroup({
    Name: new FormControl(''),
  });

  createCategory() {
    let name = this.createForm.controls["Name"].value;
    this.categoryService.createCategory(name).subscribe(cat => this.router.navigate(['categories/all']));
  }
  
}




