import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormControl, FormGroup } from '@angular/forms';
import { UserService } from '../Shared/Services/UserService';
import { CategoryService } from '../Shared/Services/CategoryService';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'delete-category',
  templateUrl: './delete-category.component.html'
})
export class DeleteCategoryComponent implements OnInit {

  constructor(private http: HttpClient, private categoryService: CategoryService, private router: Router, private route: ActivatedRoute) { }
  category;

  categoryName = new FormControl('');
  ngOnInit() {
    this.categoryService.getCategory(+this.route.snapshot.params["id"]).subscribe(cat => this.setCategory(cat));

  }
  setCategory(cat) {
    this.category = cat;
    this.categoryName.setValue(cat.name);
  }
  delete(id: number) {
    this.categoryService.delete(id).subscribe(cat => this.router.navigate(['categories/all']));
  }
}




